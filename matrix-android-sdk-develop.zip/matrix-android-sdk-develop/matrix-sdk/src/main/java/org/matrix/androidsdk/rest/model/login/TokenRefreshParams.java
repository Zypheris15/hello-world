package org.matrix.androidsdk.rest.model.login;


public class TokenRefreshParams {
    public String refresh_token;
}

