Contributing code to Matrix
===========================

Please see https://github.com/matrix-org/synapse/blob/master/CONTRIBUTING.rst
for details on how to contribute code to Matrix.org projects!
