Joachim Reigle <Joachim at matrix.org>
 * First implementation of the android client

Kegan Dougal <kegan at matrix.org>
 * Core developer

Yannick Le Collen <yannick at matrix.org>
 * Core developer

Matthew Hodgson <matthew at matrix.org>
 * General doc & housekeeping

Mitchell Hentges <mitchhentges at protonmail.com>
 * PR #35, PR #36, etc
 
Matthias Kesler <mitchhentges at protonmail.com>
 * PR #251: Send Access-Token as header instead of query param
